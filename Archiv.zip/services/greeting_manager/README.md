# Greeting Manager

Begrüßungsmanager mit generalisierten und personalisierten News-Karten, Projekt- und Memory-Karten sowie Curate-Feedback. Nutzt Agents für Topic-Planung, News-Fetching, Card-Generierung, Related Articles und Bildprompts.
