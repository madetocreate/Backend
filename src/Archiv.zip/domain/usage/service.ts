import { UsageEvent } from "./types";

export async function recordUsageEvent(event: UsageEvent): Promise<void> {
  void event;
  return;
}
