import { GreetingCard } from "./cardTypes";
import { TopicPlan } from "./topicPlanner";

export interface GreetingContext {
  userId: string;
  locale: string;
  now: string;
}

export interface GreetingManagerDeps {
  loadUserProfile: (userId: string) => Promise<unknown>;
  loadMemorySummary: (userId: string) => Promise<unknown>;
  planTopics: (context: GreetingContext, profile: unknown, memory: unknown) => Promise<TopicPlan>;
  fetchNewsCards: (context: GreetingContext, topicPlan: TopicPlan) => Promise<GreetingCard[]>;
  fetchProjectCards: (context: GreetingContext) => Promise<GreetingCard[]>;
  fetchCurateCards: (context: GreetingContext) => Promise<GreetingCard[]>;
}

export async function buildGreetingFeed(
  context: GreetingContext,
  deps: GreetingManagerDeps
): Promise<GreetingCard[]> {
  const profile = await deps.loadUserProfile(context.userId);
  const memory = await deps.loadMemorySummary(context.userId);
  const topicPlan = await deps.planTopics(context, profile, memory);
  const [newsCards, projectCards, curateCards] = await Promise.all([
    deps.fetchNewsCards(context, topicPlan),
    deps.fetchProjectCards(context),
    deps.fetchCurateCards(context)
  ]);
  const allCards: GreetingCard[] = [
    ...newsCards,
    ...projectCards,
    ...curateCards
  ];
  return allCards;
}
