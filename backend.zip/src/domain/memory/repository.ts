import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";
import os from "os";
import {
  LocalMemoryRecord,
  MemorySearchRequest,
  MemorySearchResult,
  MemoryWriteRequest,
  MemoryItemType
} from "./types";

const memoryDir = path.join(os.homedir(), "Documents", "Backend-Data");
const memoryFilePath = path.join(memoryDir, "memory.jsonl");

const localMemory: LocalMemoryRecord[] = [];

function ensureMemoryDir() {
  if (!fs.existsSync(memoryDir)) {
    fs.mkdirSync(memoryDir, { recursive: true });
  }
}

function loadPersistentMemory() {
  try {
    ensureMemoryDir();
    if (!fs.existsSync(memoryFilePath)) {
      return;
    }
    const raw = fs.readFileSync(memoryFilePath, "utf-8");
    if (!raw.trim()) {
      return;
    }
    const lines = raw.split("\n").filter((line) => line.trim().length > 0);
    for (const line of lines) {
      try {
        const parsed = JSON.parse(line) as any;
        if (
          parsed &&
          typeof parsed.id === "string" &&
          typeof parsed.tenantId === "string" &&
          typeof parsed.type === "string" &&
          typeof parsed.content === "string" &&
          typeof parsed.createdAt === "string"
        ) {
          const record: LocalMemoryRecord = {
            id: parsed.id,
            tenantId: parsed.tenantId,
            type: parsed.type,
            content: parsed.content,
            metadata: parsed.metadata ?? undefined,
            sourceId: parsed.sourceId ?? undefined,
            conversationId: parsed.conversationId ?? undefined,
            messageId: parsed.messageId ?? undefined,
            documentId: parsed.documentId ?? undefined,
            createdAt: new Date(parsed.createdAt)
          };
          localMemory.push(record);
        }
      } catch {
      }
    }
  } catch {
  }
}

function appendPersistentRecord(record: LocalMemoryRecord) {
  try {
    ensureMemoryDir();
    const line = JSON.stringify({
      id: record.id,
      tenantId: record.tenantId,
      type: record.type,
      content: record.content,
      metadata: record.metadata ?? null,
      sourceId: record.sourceId ?? null,
      conversationId: record.conversationId ?? null,
      messageId: record.messageId ?? null,
      documentId: record.documentId ?? null,
      createdAt: record.createdAt.toISOString()
    });
    fs.appendFileSync(memoryFilePath, line + "\n", "utf-8");
  } catch {
  }
}

function isExpired(metadata: any | undefined, createdAt: Date): boolean {
  if (!metadata || typeof metadata !== "object") {
    return false;
  }
  const meta = metadata as any;
  const now = new Date();

  if (typeof meta.expiresAt === "string") {
    const d = new Date(meta.expiresAt);
    if (!Number.isNaN(d.getTime()) && d.getTime() <= now.getTime()) {
      return true;
    }
  }

  if (typeof meta.ttlSeconds === "number" && Number.isFinite(meta.ttlSeconds) && meta.ttlSeconds > 0) {
    const expiresAtMs = createdAt.getTime() + meta.ttlSeconds * 1000;
    if (expiresAtMs <= now.getTime()) {
      return true;
    }
  }

  return false;
}

loadPersistentMemory();

export function createMemoryRecordFromWriteRequest(
  request: MemoryWriteRequest,
  text: string,
  createdAt: Date
): LocalMemoryRecord {
  return {
    id: randomUUID(),
    tenantId: request.tenantId,
    type: request.type,
    content: text,
    metadata: request.metadata,
    sourceId: request.sourceId,
    conversationId: request.conversationId,
    messageId: request.messageId,
    documentId: request.documentId,
    createdAt
  };
}

export function saveMemoryRecord(record: LocalMemoryRecord) {
  localMemory.push(record);
  appendPersistentRecord(record);
}

export async function searchMemoryRecords(
  request: MemorySearchRequest
): Promise<MemorySearchResult[]> {
  const { tenantId, type, query, limit = 20 } = request;
  const q = query.toLowerCase();
  const results: MemorySearchResult[] = [];

  for (const record of localMemory) {
    if (record.tenantId !== tenantId) {
      continue;
    }
    const meta =
      record.metadata && typeof record.metadata === "object"
        ? (record.metadata as any)
        : undefined;
    const status = meta ? meta.status : undefined;
    if (status === "deleted" || status === "suppressed") {
      continue;
    }
    if (isExpired(meta, record.createdAt)) {
      continue;
    }
    if (type && record.type !== type) {
      continue;
    }
    if (q && !record.content.toLowerCase().includes(q)) {
      if (q.length > 0) {
        continue;
      }
    }
    results.push({
      id: record.id,
      tenantId: record.tenantId,
      type: record.type,
      content: record.content,
      createdAt: record.createdAt,
      metadata: record.metadata,
      sourceId: record.sourceId,
      score: undefined
    });
    if (results.length >= limit) {
      break;
    }
  }

  return results;
}

export function getConversationMemoryRecords(params: {
  tenantId: string;
  conversationId: string;
  types?: MemoryItemType[];
  limit?: number;
}): LocalMemoryRecord[] {
  const { tenantId, conversationId, types, limit = 20 } = params;

  const filtered = localMemory.filter((record) => {
    if (record.tenantId !== tenantId) {
      return false;
    }
    if (record.conversationId !== conversationId) {
      return false;
    }
    const meta =
      record.metadata && typeof record.metadata === "object"
        ? (record.metadata as any)
        : undefined;
    const status = meta ? meta.status : undefined;
    if (status === "deleted" || status === "suppressed") {
      return false;
    }
    if (isExpired(meta, record.createdAt)) {
      return false;
    }
    if (types && types.length > 0 && !types.includes(record.type)) {
      return false;
    }
    return true;
  });

  filtered.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

  if (filtered.length <= limit) {
    return filtered;
  }

  return filtered.slice(filtered.length - limit);
}

export function updateMemoryStatus(
  tenantId: string,
  id: string,
  status: "active" | "archived" | "deleted" | "suppressed"
): boolean {
  let changed = false;
  for (const record of localMemory) {
    if (record.tenantId === tenantId && record.id === id) {
      const metadata = record.metadata ? { ...record.metadata } : {};
      (metadata as any).status = status;
      record.metadata = metadata as any;
      changed = true;
      break;
    }
  }
  if (!changed) {
    return false;
  }
  try {
    ensureMemoryDir();
    const tmpPath = memoryFilePath + ".tmp";
    const lines: string[] = [];
    for (const record of localMemory) {
      const line = JSON.stringify({
        id: record.id,
        tenantId: record.tenantId,
        type: record.type,
        content: record.content,
        metadata: record.metadata ?? null,
        sourceId: record.sourceId ?? null,
        conversationId: record.conversationId ?? null,
        messageId: record.messageId ?? null,
        documentId: record.documentId ?? null,
        createdAt: record.createdAt.toISOString()
      });
      lines.push(line);
    }
    fs.writeFileSync(tmpPath, lines.join("\n") + "\n", "utf-8");
    fs.renameSync(tmpPath, memoryFilePath);
  } catch {
    return false;
  }
  return true;
}
